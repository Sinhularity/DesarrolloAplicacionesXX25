package mx.uv.coatza.SS.eShop.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import mx.uv.coatza.SS.eShop.dto.CreateProductDTO;
import mx.uv.coatza.SS.eShop.dto.ProductDTO;
import mx.uv.coatza.SS.eShop.model.Product;
import mx.uv.coatza.SS.eShop.repository.ProductRepository;

@Service
public class ProductService {
    @Autowired
    private ProductRepository productRepository;

    // This class will handle the business logic for the Product entity.
    // It will interact with the ProductRepository to perform CRUD operations.

    public List<ProductDTO> getAllProductDTOs() {
        List<Product> products = productRepository.getAllProducts();
        return products.stream()
                .map(product -> new ProductDTO(product.getId(), product.getName(), product.getQuantity(),
                        product.getPrice()))
                .toList();
    }

    private Product toModelProduct(ProductDTO productDTO) {
        return new Product(productDTO.getId(), productDTO.getName(), productDTO.getQuantity(), productDTO.getPrice());
    }

    private Product toModelProduct(CreateProductDTO productDTO) {
        return new Product(0, productDTO.getName(), productDTO.getQuantity(), productDTO.getPrice());
    }

    private ProductDTO toDTOProduct(Product product) {
        return new ProductDTO(product.getId(), product.getName(), product.getQuantity(), product.getPrice());
    }

    public ProductDTO saveProduct(ProductDTO productDTO) {
        Product product = toModelProduct(productDTO);
        product = productRepository.saveProduct(product);
        return toDTOProduct(product);
    }

    public ProductDTO saveProduct(CreateProductDTO productDTO) {
        Product product = toModelProduct(productDTO);
        product = productRepository.saveProduct(product);
        return toDTOProduct(product);
    }

}
