package mx.uv.coatza.SS.eShop.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Min;

public class CreateProductDTO {
    @NotBlank(message = "Name cannot be blank.")
    private String name;

    @Min(value = 1, message = "Quantity must be at least 1.")
    private int quantity;

    @DecimalMin(value = "0.01", message = "Price must be greater than 0.")
    private double price;

    public String getName() {
        return name;
    }

    public int getQuantity() {
        return quantity;
    }

    public double getPrice() {
        return price;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public void setPrice(double price) {
        this.price = price;
    }

}
