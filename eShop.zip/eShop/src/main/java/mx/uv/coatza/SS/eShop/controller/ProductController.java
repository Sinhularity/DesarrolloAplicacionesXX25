package mx.uv.coatza.SS.eShop.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import jakarta.validation.Valid;
import mx.uv.coatza.SS.eShop.dto.CreateProductDTO;
import mx.uv.coatza.SS.eShop.dto.ProductDTO;
import mx.uv.coatza.SS.eShop.service.ProductService;

@RestController
public class ProductController {
    @Autowired
    private ProductService productService;

    @RequestMapping("getAllProducts")
    public List<ProductDTO> getAllProducts() {
        return productService.getAllProductDTOs();
    }

    @RequestMapping("createProduct")
    public ProductDTO createProduct(@Valid @RequestBody CreateProductDTO productDTO) {
        return productService.saveProduct(productDTO);
    }
}
