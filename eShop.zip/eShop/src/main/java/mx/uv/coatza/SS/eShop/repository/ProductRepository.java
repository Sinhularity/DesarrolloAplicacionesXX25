package mx.uv.coatza.SS.eShop.repository;

import java.util.LinkedList;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Repository;

import mx.uv.coatza.SS.eShop.model.Product;

@Repository
public class ProductRepository {
    // This class will handle the database operations for the Product entity.
    // For now, we can implement basic CRUD operations.
    // In a real application, this would typically extend a JPA repository
    // interface.

    private long currentId;
    private List<Product> products;

    public ProductRepository() {
        this.currentId = 0;
        this.products = new LinkedList<>();
    }

    public List<Product> getAllProducts() {
        return products;
    }

    public Product saveProduct(Product temProduct) {
        temProduct.setId(++currentId);
        products.add(temProduct);
        return temProduct;
    }

    public Optional<Product> getById() {
        Product product = null;
        for (Product p : products) {
            if (p.getId() == currentId) {
                product = p;
                return Optional.of(product);
            }
        }
        return Optional.empty();
    }

    public void update (long id, Product product) {
        Optional<Product> entry = getById();

        if (!entry.isPresent()) {
            return;
        }

        Product tempProduct = entry.get();

        if (tempProduct.getName() != null) {
            tempProduct.setName(product.getName());
        }
        if (tempProduct.getPrice() > 0) {
            tempProduct.setPrice(product.getPrice());
        }
        if (product.getQuantity() > 0) {
            tempProduct.setQuantity(product.getQuantity());
        }
    }
}
